-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 03, 2023 at 02:37 PM
-- Server version: 8.0.28
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tekstil`
--

-- --------------------------------------------------------

--
-- Table structure for table `erkek`
--

CREATE TABLE `erkek` (
  `id` int NOT NULL,
  `adı` varchar(50) NOT NULL,
  `renk` varchar(20) NOT NULL,
  `fiyat` varchar(50) CHARACTER SET latin5 COLLATE latin5_turkish_ci NOT NULL,
  `beden` varchar(50) CHARACTER SET latin5 COLLATE latin5_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin5;

--
-- Dumping data for table `erkek`
--

INSERT INTO `erkek` (`id`, `adı`, `renk`, `fiyat`, `beden`) VALUES
(1, 'Slim Fit Erkek  Antrasit Mont', 'siyah', '1.200.00 TL', 'S / M / XS'),
(2, ' Erkek Haki Renk Italyan Kesim Pantolon', 'Haki', '1.200 TL', 'XL / L / S'),
(3, 'Erkek Sweatshirt Uzun Kollu', 'Beyaz', '987.00 TL', 'XM / M / S / XLL'),
(4, ' ERKEK KAPŞONLU SWEATSHİRT', 'Beyaz', '429.99 TL', 'XM / M / S / XLL');

-- --------------------------------------------------------

--
-- Table structure for table `kadin`
--

CREATE TABLE `kadin` (
  `id` int NOT NULL,
  `adı` varchar(100) NOT NULL,
  `renk` varchar(20) NOT NULL,
  `fiyat` varchar(50) NOT NULL,
  `beden` varchar(50) CHARACTER SET latin5 COLLATE latin5_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin5;

--
-- Dumping data for table `kadin`
--

INSERT INTO `kadin` (`id`, `adı`, `renk`, `fiyat`, `beden`) VALUES
(1, 'Kadın takım elbise ofis pantolon seti', 'gri', '987.00 TL', 'XM / M / S / XLL'),
(2, 'Yaz Kadın Tişört Japon Anime', 'Beyaz', '895.00 TL', 'XL / L / S'),
(3, 'Gri Kadın Spor Ayakkabı', 'gri', '109.99 TL', '44 / 36 / 37'),
(4, 'Buyfun Kadın Etekli Mayo', 'siyah', '499.99 TL', 'XL / L / S');

-- --------------------------------------------------------

--
-- Table structure for table `stok`
--

CREATE TABLE `stok` (
  `id` int NOT NULL,
  `urun_tur` varchar(250) NOT NULL,
  `urun_kat` varchar(250) NOT NULL,
  `urun_ad` varchar(250) NOT NULL,
  `urun_resim` varchar(500) NOT NULL,
  `adet` int NOT NULL,
  `fiyat` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin5;

--
-- Dumping data for table `stok`
--

INSERT INTO `stok` (`id`, `urun_tur`, `urun_kat`, `urun_ad`, `urun_resim`, `adet`, `fiyat`) VALUES
(1, '0', 'TİŞÖRT', 'Sarı tişört', 'https://www.madmext.com/Uploads/UrunResimleri/thumb/madmext-erkek-renk-bloklu-siyah-tisort--4a0d-.jpg', 50, 800),
(2, '0', 'TİŞÖRT', 'Bisiklet yaka', 'https://www.madmext.com/Uploads/UrunResimleri/thumb/madmext-erkek-renk-bloklu-siyah-tisort--4a0d-.jpg', 2, 1500),
(3, '0', 'TİŞÖRT', 'looo tişört', 'https://www.madmext.com/Uploads/UrunResimleri/thumb/madmext-erkek-renk-bloklu-siyah-tisort--4a0d-.jpg', 50, 800),
(4, '0', 'TİŞÖRT', 'V yaka', 'https://www.madmext.com/Uploads/UrunResimleri/thumb/madmext-erkek-renk-bloklu-siyah-tisort--4a0d-.jpg', 2, 1500),
(5, '0', 'PANTOLON', 'Mavi Pantolon', 'https://cdn.dsmcdn.com/ty31/product/media/images/20201205/16/35288495/76014223/1/1_org_zoom.jpg', 20, 8000),
(6, '0', 'PANTOLON', 'ONLY Pantolon', 'https://cdn.dsmcdn.com/ty31/product/media/images/20201205/16/35288495/76014223/1/1_org_zoom.jpg', 20, 8000),
(7, '0', 'PANTOLON', 'Gri Pantolon', 'https://cdn.dsmcdn.com/ty31/product/media/images/20201205/16/35288495/76014223/1/1_org_zoom.jpg', 20, 8000),
(8, '0', 'PANTOLON', 'asas Pantolon', 'https://cdn.dsmcdn.com/ty31/product/media/images/20201205/16/35288495/76014223/1/1_org_zoom.jpg', 20, 8000),
(9, '1', 'TİŞÖRT', 'Sarı tişört', 'https://img-colinstr.mncdn.com/Assets/Branch/Thumbs/kahverengi_kadin_tshirt_kkol_159014.jpeg', 50, 800),
(10, '1', 'TİŞÖRT', 'Bisiklet yaka', 'https://img-colinstr.mncdn.com/Assets/Branch/Thumbs/kahverengi_kadin_tshirt_kkol_159014.jpeg', 2, 1500),
(11, '1', 'TİŞÖRT', 'looo tişört', 'https://img-colinstr.mncdn.com/Assets/Branch/Thumbs/kahverengi_kadin_tshirt_kkol_159014.jpeg', 50, 800),
(12, '1', 'TİŞÖRT', 'V yaka', 'https://img-colinstr.mncdn.com/Assets/Branch/Thumbs/kahverengi_kadin_tshirt_kkol_159014.jpeg', 2, 1500),
(13, '1', 'PANTOLON', 'Mavi Pantolon', 'https://www.sefamerve.com/image/cache/data/202202/25/sefamerve_pantolon_ymy2034b_01_8269021645790621786_1-752x1152.jpg', 20, 8000),
(14, '1', 'PANTOLON', 'ONLY Pantolon', 'https://www.sefamerve.com/image/cache/data/202202/25/sefamerve_pantolon_ymy2034b_01_8269021645790621786_1-752x1152.jpg', 20, 8000),
(15, '1', 'PANTOLON', 'Gri Pantolon', 'https://www.sefamerve.com/image/cache/data/202202/25/sefamerve_pantolon_ymy2034b_01_8269021645790621786_1-752x1152.jpg', 20, 8000),
(16, '1', 'PANTOLON', 'asas Pantolon', 'https://www.sefamerve.com/image/cache/data/202202/25/sefamerve_pantolon_ymy2034b_01_8269021645790621786_1-752x1152.jpg', 20, 8000),
(17, '2', 'TİŞÖRT', 'Sarı tişört', '', 50, 800),
(18, '2', 'TİŞÖRT', 'Bisiklet yaka', '', 2, 1500),
(19, '2', 'TİŞÖRT', 'looo tişört', '', 50, 800),
(20, '2', 'TİŞÖRT', 'V yaka', '', 2, 1500),
(21, '2', 'PANTOLON', 'Mavi Pantolon', '', 20, 8000),
(22, '2', 'PANTOLON', 'ONLY Pantolon', '', 20, 8000),
(23, '2', 'PANTOLON', 'Gri Pantolon', '', 20, 8000),
(24, '2', 'PANTOLON', 'asas Pantolon', '', 20, 8000);

-- --------------------------------------------------------

--
-- Table structure for table `uyeler`
--

CREATE TABLE `uyeler` (
  `id` int NOT NULL,
  `ad` varchar(250) NOT NULL,
  `soyad` varchar(250) NOT NULL,
  `eposta` varchar(250) NOT NULL,
  `kadi` varchar(250) NOT NULL,
  `sifre` varchar(250) NOT NULL,
  `yet` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin5;

--
-- Dumping data for table `uyeler`
--

INSERT INTO `uyeler` (`id`, `ad`, `soyad`, `eposta`, `kadi`, `sifre`, `yet`) VALUES
(1, 'gfhgf', 'fgh', 'fghfh', 'ayhan', 'ayhan', 0),
(2, 'fs', 'dfsfd', 'dfsd', 'sdfsd', '222', 0),
(3, 'fd', 'dfg', 'gdfg@fdgdf.com', 'dg', '12', 0),
(4, 'çiko', 'tala', 'ssss@sss', 'asd', 'asd', 0),
(5, 'ser', 'to', 'iii@', 'ok', 'iş', 0),
(6, 'çöm', 'çöm', 'çöm@', 'çöm', 'çöm', 0),
(7, 'nurullah', 'gül', 'nur@jhbdh', 'necmi', 'necmi', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `erkek`
--
ALTER TABLE `erkek`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kadin`
--
ALTER TABLE `kadin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stok`
--
ALTER TABLE `stok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uyeler`
--
ALTER TABLE `uyeler`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `erkek`
--
ALTER TABLE `erkek`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `kadin`
--
ALTER TABLE `kadin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `stok`
--
ALTER TABLE `stok`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `uyeler`
--
ALTER TABLE `uyeler`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
