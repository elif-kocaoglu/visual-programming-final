﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tekstil_final_projesi
{
    public partial class cocuk : Form
    {
        anasayfa anasayfa = new anasayfa();

        public cocuk(anasayfa cocuk)
        {
            InitializeComponent();
            anasayfa = cocuk;
        }

        private void cocuk_Load(object sender, EventArgs e)
        {
            pictureBox5.ImageLocation = "https://cdn.dsmcdn.com/mnresize/500/-/ty103/product/media/images/20210416/11/80599173/113370620/1/1_org.jpg";
            pictureBox4.ImageLocation = "https://floimages.mncdn.com/media/catalog/product/22-08/24/4dk263380910-0.jpg";
            pictureBox3.ImageLocation = "https://www.aktextile.com/resimler/sayfalar/urun-resim/cocuk-tisort-imalat-107.jpg";
            pictureBox2.ImageLocation = "https://cdn.dsmcdn.com/mnresize/500/-/ty112/product/media/images/20210505/21/86144766/171437155/1/1_org.jpg";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            anasayfa anasayfa = new anasayfa();
            anasayfa.Show();
            this.Close();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            erkekmenu erkekmenu = new erkekmenu(anasayfa);
            erkekmenu.Show();
            this.Close();



        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            kadınmenü kadınmenü = new kadınmenü(anasayfa);
            kadınmenü.Show();
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
             kadınmenü kadınmenü = new kadınmenü(anasayfa);
            kadınmenü.Show();
            this.Close();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            erkekmenu erkekmenu = new erkekmenu(anasayfa);
            erkekmenu.Show();
            this.Close();
        }
    }
}
