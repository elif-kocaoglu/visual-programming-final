﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tekstil_final_projesi
{
    public partial class balıkesir : Form
    {
        anasayfa anasayfa = new anasayfa();

        public balıkesir(anasayfa balıkesir)
        {
            InitializeComponent();
            anasayfa = balıkesir;
        }

        private void balıkesir_Load(object sender, EventArgs e)
        {
            pictureBox5.ImageLocation = "https://img-lcwaikiki.mncdn.com/mnresize/1200/-/pim/productimages/20221/6248087/l_20221-s2o325z8-1bq_a.jpg";
            pictureBox4.ImageLocation = "https://www.mansetturkiye.com/images/habergaleri/2020/09/balikesirspor-yeni-sezon-formalarini-tanitti-20200907AW10-3.jpg";
            pictureBox3.ImageLocation = "http://megaatki.com/upload/resimler/mini/balikesirspor_taraftar_atkisi.jpg";
            pictureBox2.ImageLocation = "https://media06.ligtv.com.tr/img/news/2016/6/15/50-yil-formalari-satista/424_370/b_3.jpg";
        }

        private void aNASAYFAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            anasayfa anasayfa = new anasayfa();
            anasayfa.Show();
            this.Hide();
        }

        private void erkekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            erkekmenu erk = new erkekmenu(anasayfa);
            erk.Show();
            this.Hide();

        }

        private void kADINToolStripMenuItem_Click(object sender, EventArgs e)
        {
            kadınmenü kadınmenü = new kadınmenü(anasayfa);
            kadınmenü.Show();
            this.Hide();
        }

        private void çOCUKToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cocuk cocuk= new cocuk(anasayfa);
            cocuk.Show();
            this.Hide();
        }
    }
}
