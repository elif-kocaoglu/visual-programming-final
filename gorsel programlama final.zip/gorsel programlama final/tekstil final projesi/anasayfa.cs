﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace tekstil_final_projesi
{
    public partial class anasayfa : Form
    {
        public static anasayfa af;
        public bool login;
        public int kullanici_id;
        public int yetki;
        public anasayfa()
        {
            InitializeComponent();
            af = this;
        }
        private void erkekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            erkekmenu erkekmenu=new erkekmenu(this);
            erkekmenu.Show();
            this.Hide();
        }

        private void kADINToolStripMenuItem_Click(object sender, EventArgs e)
        {
            kadınmenü kadınmenü = new kadınmenü(this);
            kadınmenü.Show();
            this.Hide();
        }

        private void üYEGİRİŞİToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ÜYEOL üYEOL=new ÜYEOL();
            üYEOL.Show();

        }

        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            anasayfa form1 = new anasayfa();
            form1.Close();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
           
        }

        private void çOCUKToolStripMenuItem_Click(object sender, EventArgs e)
        {

            cocuk cocuk = new cocuk(this);
            cocuk.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            balıkesir balıkesir = new balıkesir(this);
            balıkesir.Show();
            this.Hide();
        }

        private void iLETİŞİMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            iletişim iletişim =new iletişim(this);
            iletişim.Show();
            this.Hide();
        }

        private void sEPETİMToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
