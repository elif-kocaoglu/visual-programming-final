﻿namespace tekstil_final_projesi
{
    partial class anasayfa
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(anasayfa));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aNASAYFAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.erkekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kADINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çOCUKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEPETİMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iLETİŞİMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(731, 390);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Gray;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aNASAYFAToolStripMenuItem,
            this.erkekToolStripMenuItem,
            this.kADINToolStripMenuItem,
            this.çOCUKToolStripMenuItem,
            this.sEPETİMToolStripMenuItem,
            this.iLETİŞİMToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(731, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // aNASAYFAToolStripMenuItem
            // 
            this.aNASAYFAToolStripMenuItem.Name = "aNASAYFAToolStripMenuItem";
            this.aNASAYFAToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.aNASAYFAToolStripMenuItem.Text = "ANA SAYFA";
            // 
            // erkekToolStripMenuItem
            // 
            this.erkekToolStripMenuItem.Name = "erkekToolStripMenuItem";
            this.erkekToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.erkekToolStripMenuItem.Text = "ERKEK";
            this.erkekToolStripMenuItem.Click += new System.EventHandler(this.erkekToolStripMenuItem_Click);
            // 
            // kADINToolStripMenuItem
            // 
            this.kADINToolStripMenuItem.Name = "kADINToolStripMenuItem";
            this.kADINToolStripMenuItem.Size = new System.Drawing.Size(68, 24);
            this.kADINToolStripMenuItem.Text = "KADIN";
            this.kADINToolStripMenuItem.Click += new System.EventHandler(this.kADINToolStripMenuItem_Click);
            // 
            // çOCUKToolStripMenuItem
            // 
            this.çOCUKToolStripMenuItem.Name = "çOCUKToolStripMenuItem";
            this.çOCUKToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.çOCUKToolStripMenuItem.Text = "ÇOCUK";
            this.çOCUKToolStripMenuItem.Click += new System.EventHandler(this.çOCUKToolStripMenuItem_Click);
            // 
            // sEPETİMToolStripMenuItem
            // 
            this.sEPETİMToolStripMenuItem.Name = "sEPETİMToolStripMenuItem";
            this.sEPETİMToolStripMenuItem.Size = new System.Drawing.Size(80, 24);
            this.sEPETİMToolStripMenuItem.Text = "SEPETİM";
            this.sEPETİMToolStripMenuItem.Click += new System.EventHandler(this.sEPETİMToolStripMenuItem_Click);
            // 
            // iLETİŞİMToolStripMenuItem
            // 
            this.iLETİŞİMToolStripMenuItem.Name = "iLETİŞİMToolStripMenuItem";
            this.iLETİŞİMToolStripMenuItem.Size = new System.Drawing.Size(79, 24);
            this.iLETİŞİMToolStripMenuItem.Text = "İLETİŞİM";
            this.iLETİŞİMToolStripMenuItem.Click += new System.EventHandler(this.iLETİŞİMToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(33, 145);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(183, 47);
            this.button1.TabIndex = 3;
            this.button1.Text = "ALIŞVERİŞE BAŞLA   ->";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(457, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "HOŞ GELDİNN";
            this.label1.Visible = false;
            // 
            // anasayfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(731, 417);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "anasayfa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aNASAYFAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem erkekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kADINToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çOCUKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEPETİMToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem iLETİŞİMToolStripMenuItem;
    }
}

