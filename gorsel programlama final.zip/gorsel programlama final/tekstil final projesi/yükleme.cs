﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tekstil_final_projesi
{
    public partial class yükleme : Form
    {
        public yükleme()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel2.Width += 9;
            if (panel2.Width>=613)
            {
                timer1.Stop();
                GİRİŞ  gİRİŞ=new GİRİŞ();
                gİRİŞ.Show();
                this.Hide();
            }
        }

        private void yükleme_Load(object sender, EventArgs e)
        {

        }
    }
}
