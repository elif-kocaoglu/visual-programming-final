﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace tekstil_final_projesi
{
    public partial class erkekmenu : Form
    {
       anasayfa anasayfa = new anasayfa();

        public static erkekmenu ek;
        public int secili;
        public erkekmenu(anasayfa erkekmenu) // araştır
        {
            InitializeComponent();// araştır
            anasayfa = erkekmenu;
            ek= this;
        }
        baglantı bg = new baglantı();

        void detay(string parcalama)
        {
            int x =Convert.ToInt32(parcalama);
           secili = x;

            detaylıbilgi2 db = new detaylıbilgi2();
            db.Show();
        }

        void yukleme(string x)
        {
            List<string> dizi1 = new List<string>();
            List<string> dizi2 = new List<string>();


            bg.con_bag.Open();
            MySqlCommand cmd = new MySqlCommand("select * from stok where urun_kat='"+x.ToString()+"' and urun_tur='0'", bg.con_bag);
            MySqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                dizi1.Add(dr["urun_ad"].ToString()+" / "+dr["id"]);
      
                dizi2.Add(dr["urun_resim"].ToString());
  
            }

            button1.Text = dizi1[0];
            button2.Text = dizi1[1];
            button3.Text = dizi1[2];
            button4.Text = dizi1[3];

            pictureBox2.ImageLocation = dizi2[0];
            pictureBox3.ImageLocation = dizi2[0];
            pictureBox4.ImageLocation = dizi2[0];
            pictureBox5.ImageLocation = dizi2[0];
            label2.Text = "Toplam Stok = " + dizi1.Count.ToString();

            bg.con_bag.Close();


        }
        private void erkekmenu_Load(object sender, EventArgs e)
        {
            yukleme("TİŞÖRT");
       
           

        }

        private void aNASAYFAToolStripMenuItem_Click(object sender, EventArgs e) // açıklamayı yazamadım araştır
        {
            anasayfa anasayfa = new anasayfa();
            anasayfa.Show();// formu gösterme
            this.Hide();// formu gizleme
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "TİŞÖRT")
            {

                yukleme("TİŞÖRT");
            }
          else if (comboBox1.SelectedItem.ToString() == "PANTOLON")
            {

                yukleme("PANTOLON");
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            string[] parcala = button1.Text.Split('/');
            detay(parcala[1].Trim());


        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            kadınmenü kadınmenü = new kadınmenü(anasayfa);
            kadınmenü.Show();
            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {


            string[] parcala = button1.Text.Split('/');
            detay(parcala[1].Trim());



        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            string[] parcala = button3.Text.Split('/');
            detay(parcala[1].Trim());

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] parcala = button2.Text.Split('/');
            detay(parcala[1].Trim());


        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            string[] parcala = button2.Text.Split('/');
            detay(parcala[1].Trim());

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string[] parcala = button3.Text.Split('/');
            detay(parcala[1].Trim());


        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            string[] parcala = button4.Text.Split('/');
            detay(parcala[1].Trim());


        }

        private void button4_Click(object sender, EventArgs e)
        {
            string[] parcala = button4.Text.Split('/');
            detay(parcala[1].Trim());


        }


        private void erkekmenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            
          
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            cocuk cocuk = new cocuk(anasayfa);
            this.Close();
            cocuk.Show();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            kadınmenü kadınmenü = new kadınmenü(anasayfa);
            kadınmenü.Show();
            this.Close();
        }
    }
    
}
