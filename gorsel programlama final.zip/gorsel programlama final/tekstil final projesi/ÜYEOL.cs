﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace tekstil_final_projesi
{
    public partial class ÜYEOL : Form
    {
        public ÜYEOL()
        {
            InitializeComponent();
        }
        public MySqlConnection conn = new MySqlConnection("Server=127.0.0.1;Database=tekstil;Uid=root;Pwd='';");//formun veri tabanına giriş yapması için her açtığımda gidiyo burdan alırım

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        baglantı bag = new baglantı();

        private void button1_Click(object sender, EventArgs e)
        {


            try
            {

                if(textBox4.Text.Contains("@")) // Et işareti Varmı

                { 
                if (textBox2.Text == textBox5.Text) { 
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
                {
                    MessageBox.Show("lütfen boş yer bırakmayınız");

                }
                else
                {
                    if (bag.uye_ol(textBox1.Text, textBox3.Text, textBox4.Text, textBox6.Text, textBox2.Text))
                    {
                        // Üye Olduysa
                        MessageBox.Show(" Başarılı Bir Şekide Üye Oldunuz." +
                           " Hemen Fırsatlardan Yararlanmaya Başlayın :) ", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                            this.Close();

                        }
                else
                    {
                        MessageBox.Show("Lütfen kaydınızı kontrol edin kaydınızda hata var", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                }
                }
                else
                {
                    MessageBox.Show("Şifreniz eşleşmedi", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                }
                else
                {
                    MessageBox.Show("E posta doğru girin", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            

            }
            catch (Exception HataYakala)
            {
                MessageBox.Show("Hata: " + HataYakala.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

     

            //   İf (  textBox1.Text + textBox5.Text + textBox6.Text + textBox4.Text + textBox3.Text + textBox2.Text = "");

            //    Messagebox.Show("hata");


        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            //erkekmenu erkekmenu = new erkekmenu(anasayfa);
            //erkekmenu.Show();
            //this.Close();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }

}

