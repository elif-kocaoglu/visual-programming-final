﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tekstil_final_projesi
{
    public partial class kadınmenü : Form
    {
        anasayfa anasayfa = new anasayfa();
        public int secili;
        public static kadınmenü kad;
        public kadınmenü(anasayfa anasayfa)
        {
            InitializeComponent();
            kad = this;
            this.anasayfa = anasayfa;
        }


        baglantı bg = new baglantı();

        void detay(string parcalama)
        {
            int x = Convert.ToInt32(parcalama);
            secili = x;

            detaylıbilgi2 db = new detaylıbilgi2();
            db.Show();
        }

        void yukleme(string x)
        {
            List<string> dizi1 = new List<string>();
            List<string> dizi2 = new List<string>();


            bg.con_bag.Open();
            MySqlCommand cmd = new MySqlCommand("select * from stok where urun_kat='" + x.ToString() + "' and urun_tur='1'", bg.con_bag);
            MySqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                dizi1.Add(dr["urun_ad"].ToString() + " / " + dr["id"]);

                dizi2.Add(dr["urun_resim"].ToString());

            }

            button1.Text = dizi1[0];
            button2.Text = dizi1[1];
            button3.Text = dizi1[2];
            button4.Text = dizi1[3];

            pictureBox2.ImageLocation = dizi2[0];
            pictureBox3.ImageLocation = dizi2[0];
            pictureBox4.ImageLocation = dizi2[0];
            pictureBox5.ImageLocation = dizi2[0];
            label1.Text = "Toplam Stok = " + dizi1.Count.ToString();

            bg.con_bag.Close();


        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            erkekmenu erkekmenu = new erkekmenu(anasayfa);
            erkekmenu.Show();
            this.Close();
        }

        private void erkekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            erkekmenu erkekmenu = new erkekmenu(anasayfa);
            erkekmenu.Show();
            this.Close();
        }

        private void aNASAYFAToolStripMenuItem_Click(object sender, EventArgs e)
        {
           anasayfa form1 = new anasayfa();
            form1.Show();
            this.Close();

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            string[] parcala = button1.Text.Split('/');
            detay(parcala[1].Trim());

        }

        private void kadınmenü_Load(object sender, EventArgs e)
        {
            yukleme("TİŞÖRT");
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            string[] parcala = button2.Text.Split('/');
            detay(parcala[1].Trim());

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            string[] parcala = button3.Text.Split('/');
            detay(parcala[1].Trim());

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            string[] parcala = button4.Text.Split('/');
            detay(parcala[1].Trim());

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            erkekmenu erkekmenu = new erkekmenu(anasayfa);
            erkekmenu.Show();
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (comboBox1.SelectedItem.ToString() == "TİŞÖRT")
            {

                yukleme("TİŞÖRT");
            }
            else if (comboBox1.SelectedItem.ToString() == "PANTOLON")
            {

                yukleme("PANTOLON");
            }

      
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] parcala = button1.Text.Split('/');
            detay(parcala[1].Trim());

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] parcala = button2.Text.Split('/');
            detay(parcala[1].Trim());

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string[] parcala = button3.Text.Split('/');
            detay(parcala[1].Trim());

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string[] parcala = button4.Text.Split('/');
            detay(parcala[1].Trim());

        }
    }
}
