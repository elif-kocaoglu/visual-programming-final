﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tekstil_final_projesi
{
    public partial class iletişim : Form
    {
        anasayfa anasayfa = new anasayfa();
        //     string documentText =
        //        @"<!DOCTYPE html>
        //<html>
        //  <head>
        //    <title>Simple Map</title>
        //    <meta name=""viewport"" content=""initial-scale=1.0"">
        //    <meta charset = ""utf-8"" >
        //    <style>
        //      html, body {
        //        height: 100%;
        //        margin: 0;
        //        padding: 0;
        //      }
        //      #map {
        //        height: 100%;
        //     }
        //    </style>
        //  </head>
        //  <body>
        //    <div id=""map""></ div >
        //    <script src=""https://maps.googleapis.com/maps/api/js?key=AIzaSyD6fnLCUUinYwX3WXCr2-2wG5FbOdkbngc&callback=initMap"" async defer></script>
        //    <script>
        //      var map;
        //      function initMap()
        //      {
        //          map = new google.maps.Map(document.getElementById('map'), {
        //          center: { lat: 41.0054958, lng: 28.8720966},
        //          zoom: 11
        //        });

        //        google.maps.event.addListener(map, 'click', function(e) {
        //                window.external.Callback(e.latLng.lat(),e.latLng.lng());
        //             });
        //      }

        //    </script>
        //  </body>
        //</html>";

        //     public iletişim(anasayfa iletisim)
        //     {
        //         InitializeComponent();
        //         this.anasayfa = anasayfa;
        //         anasayfa = iletisim;
        //         // webBrowserMain.ScriptErrorsSuppressed = true;

        //     }

          private void iletişim_Load(object sender, EventArgs e)
            {
        //         //webBrowserMain.DocumentText = documentText;
        //         ScriptObject.Form = this;
        //         //webBrowserMain.ObjectForScripting = new ScriptObject();
           }
        //     [ComVisible(true)]
        //     public class ScriptObject
        //     {
        //         public static iletişim Form { get; set; }

        //         public void Callback(object lat, object lng)
        //         {
        //             Form.label1.Text = "Latitude : " + lat.ToString() + "  Longitude : " + lng.ToString();
        //         }
        //     }

        private void aNASAYFAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            anasayfa = new anasayfa();
            anasayfa.Show();
            this.Hide();
        }

        private void erkekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            erkekmenu erkekmenu = new erkekmenu(anasayfa);
            anasayfa.Show();
            this.Hide();
        }
    }
}
