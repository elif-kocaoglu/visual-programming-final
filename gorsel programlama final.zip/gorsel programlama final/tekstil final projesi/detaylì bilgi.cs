﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
namespace tekstil_final_projesi
{
    public partial class detaylı_bilgi : Form
    {
        public static detaylı_bilgi db;
        public int item_id;
        public detaylı_bilgi()
        {
            InitializeComponent();
            db = this;
           
        }
        baglantı bg = new baglantı();
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void detaylı_bilgi_Load(object sender, EventArgs e)
        {


            bg.con_bag.Open();
            MySqlCommand cmd = new MySqlCommand("select * from stok where id='" + item_id + "'", bg.con_bag);
            MySqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                label2.Text = dr["urun_kat"].ToString();
                label3.Text = dr["urun_ad"].ToString();

                int say = (int)dr["adet"];

                if (say < 3)
                {
                    label4.Text = "Stokta Son = " + say.ToString();

                }
                else
                {
                    label4.Text = "Stokta Sayısı = " + say.ToString();
                }
                

            }

           

            bg.con_bag.Close();


        }

        private void aNASAYFAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            anasayfa anasayfa=new anasayfa();
            anasayfa.Show();
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void listBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void erkekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //erkekmenu erkekmenu = new erkekmenu(anasayfa);
            //erkekmenu.Show();
            //this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
