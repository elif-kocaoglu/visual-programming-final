﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using MySql.Data;

namespace tekstil_final_projesi
{
    public partial class GİRİŞ : Form
    {
        public GİRİŞ()
        {
            InitializeComponent();
        }
        baglantı bgn = new baglantı();
        private void button1_Click(object sender, EventArgs e)
        {

            MySqlCommand cmd = new MySqlCommand();
            bgn.con_bag.Open();
            cmd.Connection = bgn.con_bag;
            anasayfa form1 = new anasayfa();
            cmd.CommandText = "SELECT * FROM uyeler where kadi='" + textBox6.Text + "' AND sifre='" + textBox2.Text + "'";
            MySqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                anasayfa.af.login = true;
                anasayfa.af.kullanici_id = (int)dr["id"];
                int y = (int)dr["yet"];
                if (y==1)// Admin
                {

                    anasayfa.af.yetki = 1;
                    form1.label1.Text = "Hoşgeldin Admin ";

                }
                else
                {
                    string ad = dr["ad"].ToString();
                    string soyad = dr["soyad"].ToString();
                    form1.label1.Text = "Hoşgeldin " + ad + " " + soyad;
                }
        

 

                form1.label1.Visible = true;
                form1.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullanıcı adı ya da şifre yanlış");
            }

            bgn.con_bag.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ÜYEOL üYEOL = new ÜYEOL();
            üYEOL.Show();
            
        }
    }
}
