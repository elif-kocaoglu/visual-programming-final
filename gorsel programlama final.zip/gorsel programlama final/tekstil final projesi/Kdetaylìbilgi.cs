﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tekstil_final_projesi
{
    public partial class Kdetaylıbilgi : Form
    {
        public Kdetaylıbilgi()
        {
            InitializeComponent();
        }
        public MySqlConnection conn = new MySqlConnection("Server=127.0.0.1;Database=tekstil;Uid=root;Pwd='';");//formun veri tabanına giriş yapması için her açtığımda gidiyo burdan alırım

        private void Kdetaylıbilgi_Load(object sender, EventArgs e)
        {
            MySqlCommand cmd;
            MySqlDataReader dr;

            cmd = new MySqlCommand();
            string sorgu = "Select adı from kadin WHERE id = 1";
            string deger;
            MySqlCommand komut = new MySqlCommand(sorgu, conn);
            conn.Open();
            deger = (string)komut.ExecuteScalar();
            conn.Close();
            label2.Text = deger;

            string sorgu2 = "Select renk from kadin WHERE id = 1";
            string deger2;
            MySqlCommand komut2 = new MySqlCommand(sorgu2, conn);
            conn.Open();
            deger2 = (string)komut2.ExecuteScalar();
            conn.Close();
            label3.Text = deger2;

            string sorgu3 = "Select fiyat from kadin WHERE id = 1";
            string deger3;
            MySqlCommand komut3 = new MySqlCommand(sorgu3, conn);
            conn.Open();
            deger3 = (string)komut3.ExecuteScalar();
            conn.Close();
            label4.Text = deger3;

            string sorgu4 = "Select beden from kadin WHERE id = 1";
            string deger4;
            MySqlCommand komut4 = new MySqlCommand(sorgu4, conn);
            conn.Open();
            deger4 = (string)komut4.ExecuteScalar();
            conn.Close();
            label5.Text = deger4;
            pictureBox1.ImageLocation = "https://ae01.alicdn.com/kf/H5b525b85cd834a9595494ead793bfad0u/Kad-n-tak-m-elbise-ofis-pantolon-seti-2-par-a-Set-tam-kollu-bal-ks.jpg_Q90.jpg_.webp";

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
