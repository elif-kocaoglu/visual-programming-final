﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
namespace tekstil_final_projesi
{
    public partial class detaylıbilgi2 : Form
    {
        public static detaylıbilgi2 db;
        public int item_id;
        public detaylıbilgi2()
        {
            InitializeComponent();
            db = this;
        }
        baglantı bg = new baglantı();
        private void detaylıbilgi2_Load(object sender, EventArgs e)
        {

            bg.con_bag.Open();
            MySqlCommand cmd = new MySqlCommand("select * from stok where id='" + kadınmenü.kad.secili + "'", bg.con_bag);
            MySqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                label2.Text = dr["urun_kat"].ToString();
                label3.Text = dr["urun_ad"].ToString();
                pictureBox1.ImageLocation = dr["urun_resim"].ToString();

                int say = (int)dr["adet"];

                if (say < 3)
                {
                    label4.Text = "Stokta Son = " + say.ToString();

                }
                else
                {
                    label4.Text = "Stokta Sayısı = " + say.ToString();
                }


            }



            bg.con_bag.Close();
        }

        private void erkekToolStripMenuItem_Click(object sender, EventArgs e)
        {
        //    erkekmenu erkekmenu = new erkekmenu(anasayfa);
        //    erkekmenu.Show();
        //    this.Close();
        }
}
}
