﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;

namespace tekstil_final_projesi
{
    internal class baglantı
    {
         public MySqlConnection con_bag =new MySqlConnection("server=localhost;uid=root;pwd=;database=tekstil");
         
        public bool uye_ol(string ad, string soyad, string eposta,string kadi,string sifre)
        {
            bool test=false;
            con_bag.Open();
            MySqlCommand cmd = new MySqlCommand("insert into uyeler (ad,soyad,eposta,kadi,sifre)values('"+ad+"','"+soyad+"','"
                +eposta+"','"+kadi+"','"+sifre+"') ",con_bag);
            if (cmd.ExecuteNonQuery() == 1)
                test = true;
            con_bag.Close();
            return test;
        }

        // neden sadece üye olu yaptım 

      

      
    }
}
